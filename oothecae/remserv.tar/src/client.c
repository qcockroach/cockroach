#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>


int client (void)
{
	int port, sockfd, connfd;
	struct sockaddr_in servaddr, cli;

	sockfd = socket (AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		fprintf (stderr, "socket () failed.\n");
		return 1;
	}
	printf ("Created socket\n");

	char ip[] = "192.168.0.100"; // 127.0.0.1
	port = 8080;
	bzero (&servaddr, sizeof (servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr (ip);
	servaddr.sin_port = htons (port);

	if (connect (sockfd, (struct sockaddr *)&servaddr, sizeof (servaddr)) != 0) {
		fprintf (stderr, "connect () failed.\n");
		return 1;
	}
	printf ("Connedted to server\n");
}


int main (void)
{

	client ();
	return 0;
}
