#ifndef __COCKROACH_H
#define __COCKROACH_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>


#endif